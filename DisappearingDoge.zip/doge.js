$(document).ready(function () {

    for (var i = 0; i < 8; i++) {
        $("#content").append("<img src='http://i0.kym-cdn.com/entries/icons/mobile/000/013/564/doge.jpg'>")
    }

    $("img").click(function() {
        $(this).hide("slow");
    });

    $("button").click(function() {
        $("img").show("slow");
    });

});